#!/bin/bash


cd $EXEDIR/WRFV3

./clean -a


